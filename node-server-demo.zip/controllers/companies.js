const Company = require ('../models').Company;
//const jwt = require ('jsonwebtoken');

exports.findAll = (req, res) => {
  Company.findAll ().then (companies => {
    // Send all customers to Client
    res.send (companies);
  });
};

exports.findOne = (req, res) => {
  Company.findOne ({where: {name: req.params.name}})
    .then (company => {
      // Send all customers to Client
      if (company) {
        res.send (company);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};

exports.create = (req, res) => {
  Company.create ({
    name: req.body.name,
  })
    .then (response => {
      res.send (response);
    })
    .catch (err => {
      res.send ('unable to access ');
    });
};

exports.create2 = (req, res) => {
  Company.sequelize
    .query ("insert into companies(name) values('" + req.body.name + "')")
    .spread ((results, metadata) => {
      res.send (results.body);
    });
};

exports.report = (req, res) => {
  let events = [
    {
      _id: '1',
      name: 'Bike Festival',
      description: 'New byke festival for childern.',
    },
    {
      _id: '2',
      name: 'Bike Festival',
      description: 'New byke festival for childern.',
    },
    {
      _id: '3',
      name: 'Bike Festival',
      description: 'New byke festival for childern.',
    },
  ];
  res.json (events);
};
