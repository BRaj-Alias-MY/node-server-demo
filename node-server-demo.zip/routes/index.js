const Company = require ('../controllers/companies');
const User = require ('../controllers/user.controller');
const verify = require ('../middleware/auth').verifyToken;
module.exports = app => {
  app.get ('/api/all', verify, Company.findAll);
  app.get ('/api/find/:name', Company.findOne);
  app.post ('/api/insert', Company.create);
  app.post ('/api/insert2', Company.create2);
  app.get ('/api/report', Company.report);
  app.post ('/api/user', User.create);
  app.get ('/api/users', User.getUsers);
  app.post ('/api/login', User.getUser);
};
