const User = require ('../models').User;
const jwt = require ('jsonwebtoken');
exports.create = (req, res) => {
  User.findOne ({where: {email: req.body.email}})
    .then (user => {
      if (!user) {
        User.create ({
          email: req.body.email,
          firstname: req.body.firstname,
          lastname: req.body.lastname,
          password: req.body.password,
          createdBy: 111,
          updatedBy: 111,
          status: req.body.status,
        })
          .then (response => {
            res.send (response);
          })
          .catch (err => {
            res.send (err);
          });
      } else {
        res.send ('Exists');
      }
    })
    .catch (err => {
      res.send (err);
    });
};

exports.getUsers = (req, res) => {
  User.findAll ()
    .then (users => {
      res.send (users);
    })
    .catch (err => {
      res.send (err);
    });
};

exports.getUser = (req, res) => {
  User.findOne ({where: {email: req.body.email, password: req.body.password}})
    .then (user => {
      //generate token
      let payload = {subject: user.email};
      let token = jwt.sign (payload, 'secretKey');
      // res.status(200).send({ token });
      res.status (200).json ({token: token, email: user.email});
      res.json (user);
    })
    .then (err => res.json (err));
};
